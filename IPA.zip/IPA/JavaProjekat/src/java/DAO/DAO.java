package DAO;

import beans.Bioskop;
import beans.Film;
import beans.Grad;
import beans.Klub;
import beans.Korisnik;
import beans.MenadzerRender;
import beans.Posluzenje;
import beans.PosluzenjeNaruceno;
import beans.Projekcija;
import beans.Rezervacija;
import beans.RezervacijaRender;
import beans.RezervisanaSedista;
import beans.Sala;
import beans.Sediste;
import beans.Tehnologija;
import java.sql.*;
import java.sql.ResultSet;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Map;

public class DAO {

    private Connection veza;

    public DAO() {
        String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
        String user = "root";
        String pass = "";
        try {
            //Konekcija sa bazom
            Class.forName("com.mysql.jdbc.Driver");
            veza = DriverManager.getConnection(dbUrl, user, pass);
        } catch (Exception e) {
            System.out.println("DAO.DAO.<init>() " + e.getMessage());
        }
    }

    public ArrayList<Projekcija> listaprojekcija() {
        ArrayList<Projekcija> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM projekcija");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Projekcija(Integer.parseInt(rs.getString("id")),
                        Integer.parseInt(rs.getString("film")),
                        Integer.parseInt(rs.getString("sala")),
                        Integer.parseInt(rs.getString("tehnologija")),
                        Integer.parseInt(rs.getString("premijera")),
                        Double.parseDouble(rs.getString("cena")),
                        java.sql.Date.valueOf(rs.getString("datum")), Time.valueOf(rs.getString("vreme"))));
            }
            rs.close();
            return lista;

        } catch (Exception e) {
            System.out.println("DAO.DAO.listprojekcija() " + e.getMessage());
            return null;
        }
    }

    public ArrayList<Sala> listaSala() {
        ArrayList<Sala> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM sala");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Sala(Integer.parseInt(rs.getString("id")),
                        Integer.parseInt(rs.getString("bioskop")),
                        rs.getString("naziv"),
                        Integer.parseInt(rs.getString("kapacitet"))));
            }
            rs.close();
            return lista;

        } catch (Exception e) {
            System.out.println("DAO.DAO.listasala() " + e.getMessage());
            return null;
        }
    }

    public ArrayList<Film> listafilmova() {
        ArrayList<Film> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM film");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Film(Integer.parseInt(rs.getString("id")), rs.getString("naziv"),
                        rs.getString("slika"), rs.getString("opis"), rs.getString("producent"), rs.getString("pisci"),
                        rs.getString("glumci"), rs.getString("trailer"), Integer.parseInt(rs.getString("trajanje")),
                        Integer.parseInt(rs.getString("godina")),
                        Double.parseDouble(rs.getString("ocena")), Integer.parseInt(rs.getString("zanr"))));
            }
            rs.close();
            return lista;

        } catch (Exception e) {
            System.out.println("DAO.DAO.listasala() " + e.getMessage());
            return null;
        }
    }

    public ArrayList<Korisnik> listakorisnika() {
        ArrayList<Korisnik> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM korisnik");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Korisnik(Integer.parseInt(rs.getString("id")), rs.getString("korisnicko"), rs.getString("sifra"), rs.getString("ime"), rs.getString("prezime"), rs.getString("telefon"), Integer.parseInt(rs.getString("poeni")), Integer.parseInt(rs.getString("klub")), Integer.parseInt(rs.getString("nivo"))));
            }
            rs.close();
            return lista;

        } catch (Exception e) {
            System.out.println("DAO.DAO.listakorisnika() " + e.getMessage());
            return null;
        }

    }

    public ArrayList<Bioskop> listabioskopa() {
        ArrayList<Bioskop> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM bioskop");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Bioskop(Integer.parseInt(rs.getString("id")), rs.getString("naziv"), Integer.parseInt(rs.getString("grad"))));
            }
            rs.close();

        } catch (Exception e) {
            System.out.println("DAO.DAO.listabioskopa() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public ArrayList<Tehnologija> listatehnologija() {
        ArrayList<Tehnologija> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM tehnologija");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Tehnologija(Integer.parseInt(rs.getString("id")), rs.getString("naziv")));
            }
            rs.close();

        } catch (Exception e) {
            System.out.println("DAO.DAO.listabioskopa() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public ArrayList<Grad> listagradova() {
        ArrayList<Grad> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM grad");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Grad(Integer.parseInt(rs.getString("id")), rs.getString("naziv")));
            }
            rs.close();
            return lista;

        } catch (Exception e) {
            System.out.println("DAO.DAO.listagradova() " + e.getMessage());
            return null;
        }

    }

    public ArrayList<Rezervacija> listarezervacija() {
        ArrayList<Rezervacija> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervacija");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Rezervacija(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("korisnik")), Double.parseDouble(rs.getString("ukupno")), Timestamp.valueOf(rs.getString("kreiran")), Integer.parseInt(rs.getString("potvrdjeno"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listerezervacija() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public Film detaljifilma(String id) {
        try {
            Film film = null;
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM film WHERE id='" + id + "'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                film = new Film(Integer.parseInt(rs.getString("id")), rs.getString("naziv"),
                        rs.getString("slika"), rs.getString("opis"), rs.getString("producent"), rs.getString("pisci"),
                        rs.getString("glumci"), rs.getString("trailer"), Integer.parseInt(rs.getString("trajanje")),
                        Integer.parseInt(rs.getString("godina")),
                        Double.parseDouble(rs.getString("ocena")), Integer.parseInt(rs.getString("zanr")));
            }
            rs.close();
            return film;
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljifilma() " + e.getMessage());
            return null;
        }
    }

    public Korisnik detaljikorisnika(String id) {
        try {
            Korisnik korisnik = null;
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM korisnik WHERE id='" + id + "'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                korisnik = new Korisnik(Integer.parseInt(rs.getString("id")), rs.getString("korisnicko"), rs.getString("sifra"), rs.getString("ime"), rs.getString("prezime"), rs.getString("telefon"), Integer.parseInt(rs.getString("poeni")), Integer.parseInt(rs.getString("klub")), Integer.parseInt(rs.getString("nivo")));

            }
            rs.close();
            return korisnik;
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
            return null;
        }
    }

    public void izmenikorisnika(String id, String korisnicko, String sifra, String ime, String prezime, String telefon, String poeni, String nivo) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE korisnik SET korisnicko='" + korisnicko + "', sifra='" + sifra + "', ime='" + ime + "', prezime='" + prezime + "', telefon='" + telefon + "', poeni='" + poeni + "', nivo='" + nivo + "' WHERE id='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
        }
    }

    public void izmenifilm(String id, String naziv, String slika, String opis, String producent, String pisci, String glumci, String trailer, String trajanje, String godina, String ocena, String zanr) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE film SET naziv='" + naziv + "', slika='" + slika + "', opis='" + opis + "', producent='" + producent + "', pisci='" + pisci + "', glumci='" + glumci + "', trailer='" + trailer + "', trajanje='" + trajanje + "', godina='" + godina + "', ocena='" + ocena + "', zanr='" + zanr + "' WHERE id='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
        }
    }

    public void brisikorisnika(String id) {
        try {
            PreparedStatement ps = veza.prepareStatement("DELETE FROM korisnik WHERE id='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisikorisnika() " + e.getMessage());
        }
    }

    public void brisifilm(String id) {
        try {
            PreparedStatement ps = veza.prepareStatement("DELETE FROM film WHERE id='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisifilm() " + e.getMessage());
        }
    }

    public void brisiRezervacije(int id) {
        try {
            PreparedStatement ps = veza.prepareStatement("DELETE FROM rezervacija WHERE projekcija='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisiRezervacije() " + e.getMessage());
        }
    }

    public void brisiNepotvrdjeneRezervacije(int id) {
        try {
            PreparedStatement ps = veza.prepareStatement("DELETE FROM rezervacija WHERE projekcija='" + id + "' AND potvrdjeno='0'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisiNepotvrdjeneRezervacije() " + e.getMessage());
        }
    }

    public void brisiProjekcije(int id) {
        try {
            PreparedStatement ps = veza.prepareStatement("DELETE FROM projekcija WHERE id='" + id + "'");
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisiProjekcije() " + e.getMessage());
        }
    }

    public int kreirajrezervaciju(Rezervacija r) {
        int key = -1;
        try {
            PreparedStatement ps = veza.prepareStatement("INSERT INTO rezervacija(projekcija, korisnik, ukupno, kreiran, potvrdjeno) VALUES(?,?,?,CURRENT_TIMESTAMP,'0')", Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, r.getProjekcija());
            ps.setInt(2, r.getKorisnik());
            ps.setDouble(3, r.getUkupno());
            ps.execute();
            ResultSet rs = ps.getResultSet();
            ResultSet keys = ps.getGeneratedKeys();

            keys.next();
            key = keys.getInt(1);
        } catch (Exception e) {
            System.out.println("DAO.DAO.brisifilm() " + e.getMessage());
        }
        return key;
    }
    
    public void insertFilm(Film f) {
       
        try {
            PreparedStatement ps = veza.prepareStatement("INSERT INTO film(naziv,slika,opis,producent,pisci,glumci,trailer,trajanje,godina,ocena,zanr) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, f.getNaziv());
            ps.setString(2, f.getSlika());
            ps.setString(3, f.getOpis());
            ps.setString(4, f.getProducent());
            ps.setString(5, f.getPisci());
            ps.setString(6, f.getGlumci());
            ps.setString(7, f.getTrailer());
            ps.setInt(8, f.getTrajanje());
            ps.setInt(9, f.getGodina());
            ps.setDouble(10,f.getOcena());
            ps.setInt(11,f.getZanr());
            ps.executeUpdate();
            ps.close();

        } catch (Exception e) {
            System.out.println("DAO.DAO.insertFilm() " + e.getMessage());
        }
     
    }
    
     public void updateFIlm(Film f) {
       
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE film set naziv=?,slika=?,opis=?,producent=?,pisci=?,glumci=?,trailer=?,trajanje=?,godina=?,ocena=?,zanr=? WHERE id=?");
            ps.setString(1, f.getNaziv());
            ps.setString(2, f.getSlika());
            ps.setString(3, f.getOpis());
            ps.setString(4, f.getProducent());
            ps.setString(5, f.getPisci());
            ps.setString(6, f.getGlumci());
            ps.setString(7, f.getTrailer());
            ps.setInt(8, f.getTrajanje());
            ps.setInt(9, f.getGodina());
            ps.setDouble(10,f.getOcena());
            ps.setInt(11,f.getZanr());
            ps.setInt(12,f.getId());
            ps.executeUpdate();
            ps.close();

        } catch (Exception e) {
            System.out.println("DAO.DAO.insertFilm() " + e.getMessage());
        }
     
    }


    public ArrayList<Integer> listazauzetihsedista(int id) {
        ArrayList<Integer> lista = new ArrayList<>();
        try {

            PreparedStatement ps2 = veza.prepareStatement("SELECT * FROM rezervisana_sedista rs JOIN rezervacija r on rs.idRezervacije=r.id JOIN projekcija p on r.projekcija=p.id where p.id=?");
            ps2.setInt(1, id);
            ResultSet rs2 = ps2.executeQuery();
            while (rs2.next()) {
                // zauzeta_sedista.add(new ZauzetaSedista(Integer.parseInt(rs2.getString("idRezervacije")),Integer.parseInt(rs2.getString("idSediste")),Integer.parseInt(rs2.getString("idProjekcija")),Integer.parseInt(rs2.getString("potvrdjeno"))));
                lista.add(Integer.parseInt(rs2.getString("idSediste")));
            }
            rs2.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Sediste> listasedistapoSali(int id) {
        ArrayList<Sediste> lista = new ArrayList<>();
        try {

            PreparedStatement ps = veza.prepareStatement("SELECT * FROM sediste WHERE sala=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Sediste(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("broj_sedista")), Integer.parseInt(rs.getString("sala")), Integer.parseInt(rs.getString("kategorija")), Integer.parseInt(rs.getString("red"))));
            }
            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Projekcija getProjekcijaById(int id) {
        Projekcija p = null;
        try {
            PreparedStatement ps3 = veza.prepareStatement("SELECT * FROM projekcija WHERE id=?");
            ps3.setInt(1, id);
            ResultSet rs3 = ps3.executeQuery();
            while (rs3.next()) {
                p = new Projekcija(Integer.parseInt(rs3.getString("id")), Integer.parseInt(rs3.getString("film")), Integer.parseInt(rs3.getString("sala")), Integer.parseInt(rs3.getString("tehnologija")), Integer.parseInt(rs3.getString("premijera")), Double.parseDouble(rs3.getString("cena")), java.sql.Date.valueOf(rs3.getString("datum")), Time.valueOf(rs3.getString("vreme")));

            }
            rs3.close();

        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
            return null;
        }
        System.out.println(p);
        return p;
    }

    public void InsertIntoRezervisanaSedista(int idRezervacija, String[] listasedista) {
        try {

            for (String sediste : listasedista) {
                PreparedStatement ps = veza.prepareStatement("INSERT INTO rezervisana_sedista VALUES(?,?,'0')");
                ps.setInt(1, idRezervacija);
                ps.setInt(2, Integer.parseInt(sediste));
                ps.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public ArrayList<Rezervacija> listarezervacijaByProjekcija(int id) {
        ArrayList<Rezervacija> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervacija WHERE projekcija=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Rezervacija(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("korisnik")), Double.parseDouble(rs.getString("ukupno")), Timestamp.valueOf(rs.getString("kreiran")), Integer.parseInt(rs.getString("potvrdjeno"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listarezervacijaByProjekcija() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public ArrayList<Rezervacija> listarezervacijaByKorisnik(int id) {
        ArrayList<Rezervacija> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervacija WHERE korisnik=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Rezervacija(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("korisnik")), Double.parseDouble(rs.getString("ukupno")), Timestamp.valueOf(rs.getString("kreiran")), Integer.parseInt(rs.getString("potvrdjeno"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listarezervacijaByKorisnik() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public void PotvrdiRezervaciju(int id) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE rezervacija SET potvrdjeno='1' WHERE id=?");
            ps.setInt(1, id);
            ps.execute();
            veza.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.PotvrdiRezervaciju() " + e.getMessage());
        }
    }

    public ArrayList<Posluzenje> listaposluzenja() {
        ArrayList<Posluzenje> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM posluzenje");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(new Posluzenje(Integer.parseInt(rs.getString("id")), rs.getString("slika"), rs.getString("naziv"), Double.parseDouble(rs.getString("cena"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listarezervacijaByProjekcija() " + e.getMessage());
            return null;
        }
        return lista;
    }

    public void InsertIntoPosluzenje(int idRezervacija, Map<Integer, Integer> map) {
        try {

            for (Integer s : map.keySet()) {
                PreparedStatement ps = veza.prepareStatement("INSERT INTO posluzenje_naruceno VALUES(?,?,?)");
                ps.setInt(1, idRezervacija);
                ps.setInt(2, s);
                ps.setInt(3, map.get(s));
                ps.execute();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void kreirajProjekciju(Projekcija p) {
        try {
            PreparedStatement ps = veza.prepareStatement("INSERT INTO projekcija(film,sala,tehnologija,premijera,cena,datum,vreme) VALUES('"
                    + p.getFilm() + "','" + p.getSala() + "','" + p.getTehnologija() + "','" + p.getPremijera() + "','" + p.getCena() + "','" + p.getDatum() + "','" + p.getVreme() + "')"
            );
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("DAO.DAO.kreirajProjekciju() " + e.getMessage());
        }

    }

    public void updateCena(double cena, int id) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE rezervacija SET ukupno=ukupno+? WHERE id=?");
            ps.setDouble(1, cena);
            ps.setInt(2, id);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.updateCena() " + e.getMessage());
        }
    }

    public ArrayList<RezervisanaSedista> listaSedistaByIdRezervacija(int id) {
        ArrayList<RezervisanaSedista> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervisana_sedista WHERE idRezervacije=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(id + " " + rs.getString("idSediste") + " " + rs.getString("potvrdjeno"));
                lista.add(new RezervisanaSedista(id, Integer.parseInt(rs.getString("idSediste")), Integer.parseInt(rs.getString("potvrdjeno"))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<PosluzenjeNaruceno> listaposluzenjaByIdRezervacija(int id) {
        ArrayList<PosluzenjeNaruceno> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM posluzenje_naruceno pn JOIN posluzenje p ON pn.IDPosluzenja=p.id WHERE pn.idRezervacije=? AND pn.kolicina NOT in(0)");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                lista.add(new PosluzenjeNaruceno(id,
                        new Posluzenje(Integer.parseInt(rs.getString("id")), rs.getString("slika"), rs.getString("naziv"), Double.parseDouble(rs.getString("cena"))),
                        Integer.parseInt(rs.getString("kolicina"))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Rezervacija getRezervacijaById(int id) {
        Rezervacija r = null;
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervacija WHERE id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r = new Rezervacija(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("korisnik")), Double.parseDouble(rs.getString("ukupno")), Timestamp.valueOf(rs.getString("kreiran")), Integer.parseInt(rs.getString("potvrdjeno")));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listarezervacijaByProjekcija() " + e.getMessage());
            return null;
        }
        return r;
    }

    public RezervacijaRender getRezervacijaRenderById(int id) {
        RezervacijaRender r = null;
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM rezervacija r JOIN projekcija p ON r.projekcija=p.id JOIN korisnik k on r.korisnik=k.id JOIN film f on p.film=f.id WHERE r.id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r = new RezervacijaRender(
                        id,
                        new Projekcija(Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("film")), Integer.parseInt(rs.getString("sala")), Integer.parseInt(rs.getString("tehnologija")), Integer.parseInt(rs.getString("premijera")), Double.parseDouble(rs.getString("cena")), Date.valueOf(rs.getString("datum")), Time.valueOf(rs.getString("vreme"))),
                        new Korisnik(Integer.parseInt(rs.getString("korisnik")), rs.getString("korisnicko"), rs.getString("sifra"), rs.getString("ime"), rs.getString("prezime"), rs.getString("telefon"), Integer.parseInt(rs.getString("poeni")), Integer.parseInt(rs.getString("klub")), Integer.parseInt(rs.getString("nivo"))),
                        Double.parseDouble(rs.getString("ukupno")),
                        Timestamp.valueOf(rs.getString("kreiran")),
                        Integer.parseInt(rs.getString("potvrdjeno")),
                        new Film(Integer.parseInt(rs.getString("film")), rs.getString("naziv"), rs.getString("slika"), rs.getString("opis"), rs.getString("producent"), rs.getString("pisci"), rs.getString("glumci"), rs.getString("trailer"), Integer.parseInt(rs.getString("trajanje")), Integer.parseInt(rs.getString("godina")), Double.parseDouble(rs.getString("ocena")), Integer.parseInt(rs.getString("zanr"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.listarezervacijaByProjekcija() " + e.getMessage());
            return null;
        }
        return r;
    }

    public ArrayList<MenadzerRender> getMenadzerRender() {
        ArrayList<MenadzerRender> r = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT *,SUM(r.ukupno) as ukupnoFilm, COUNT(r.id) as brojRezervacija from film f join projekcija p on p.film=f.id join rezervacija r on r.projekcija=p.id GROUP by film");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                r.add(new MenadzerRender(
                        Integer.parseInt(rs.getString("id")),
                        new Projekcija(Integer.parseInt(rs.getString("projekcija")), Integer.parseInt(rs.getString("film")), Integer.parseInt(rs.getString("sala")), Integer.parseInt(rs.getString("tehnologija")), Integer.parseInt(rs.getString("premijera")), Double.parseDouble(rs.getString("cena")), Date.valueOf(rs.getString("datum")), Time.valueOf(rs.getString("vreme"))),
                        Double.parseDouble(rs.getString("ukupno")),
                        Timestamp.valueOf(rs.getString("kreiran")),
                        Integer.parseInt(rs.getString("potvrdjeno")),
                        new Film(Integer.parseInt(rs.getString("film")), rs.getString("naziv"), rs.getString("slika"), rs.getString("opis"), rs.getString("producent"), rs.getString("pisci"), rs.getString("glumci"), rs.getString("trailer"), Integer.parseInt(rs.getString("trajanje")), Integer.parseInt(rs.getString("godina")), Double.parseDouble(rs.getString("ocena")), Integer.parseInt(rs.getString("zanr"))),
                        Double.parseDouble(rs.getString("ukupnoFilm")), Integer.parseInt(rs.getString("brojRezervacija"))));
            }
            rs.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.getMenadzerRender() " + e.getMessage());
            return null;
        }
        return r;
    }

    public ArrayList<Sediste> listaSedista() {
        ArrayList<Sediste> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM sediste");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                System.out.println(rs.getString("id") + " " + rs.getString("broj_sedista") + " " + rs.getString("sala") + " " + rs.getString("kategorija") + " " + rs.getString("red"));
                lista.add(new Sediste(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("broj_sedista")), Integer.parseInt(rs.getString("sala")), Integer.parseInt(rs.getString("kategorija")), Integer.parseInt(rs.getString("red"))));
            }
            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public ArrayList<Klub> listaKlubova() {
        ArrayList<Klub> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("SELECT * FROM klub");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                lista.add(new Klub(Integer.parseInt(rs.getString("id")), rs.getString("naziv")));
            }
            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public void updateKlub(int id, int klub) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE korisnik SET klub=? WHERE id=?");
            ps.setInt(1, klub);
            ps.setInt(2, id);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
        }
    }

    public void updatePoen(int id, int poen) {
        try {
            PreparedStatement ps = veza.prepareStatement("UPDATE korisnik SET poeni=? WHERE id=?");
            ps.setInt(1, poen);
            ps.setInt(2, id);
            ps.executeUpdate();
            ps.close();
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljikorisnika() " + e.getMessage());
        }
    }

    public Film getMostSelledMovie() {
        try {
            Film film = null;
            PreparedStatement ps = veza.prepareStatement("select f.*,SUM(r.ukupno) as uku from projekcija p join rezervacija r on r.projekcija=p.id JOIN film f on p.film=f.id GROUP by film LIMIT 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                film = new Film(Integer.parseInt(rs.getString("id")), rs.getString("naziv"),
                        rs.getString("slika"), rs.getString("opis"), rs.getString("producent"), rs.getString("pisci"),
                        rs.getString("glumci"), rs.getString("trailer"), Integer.parseInt(rs.getString("trajanje")),
                        Integer.parseInt(rs.getString("godina")),
                        Double.parseDouble(rs.getString("ocena")), Integer.parseInt(rs.getString("zanr")));
            }
            rs.close();
            return film;
        } catch (Exception e) {
            System.out.println("DAO.DAO.detaljifilma() " + e.getMessage());
            return null;
        }
    }

    public ArrayList<PosluzenjeNaruceno> MostSelledFoodAndDring() {
        ArrayList<PosluzenjeNaruceno> lista = new ArrayList<>();
        try {
            PreparedStatement ps = veza.prepareStatement("select p.*,SUM(pn.kolicina)as kolicina from posluzenje p join posluzenje_naruceno pn on p.id=pn.IDPosluzenja GROUP by p.id ORDER BY kolicina DESC");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                lista.add(new PosluzenjeNaruceno(-1,
                        new Posluzenje(Integer.parseInt(rs.getString("id")), rs.getString("slika"), rs.getString("naziv"), Double.parseDouble(rs.getString("cena"))),
                        Integer.parseInt(rs.getString("kolicina"))));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static void main(String[] args) {

        DAO dao = new DAO();

        System.out.println("*********/n/n" + dao.MostSelledFoodAndDring());
    }
}
