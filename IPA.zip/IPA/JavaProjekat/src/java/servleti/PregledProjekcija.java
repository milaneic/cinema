package servleti;

import DAO.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import beans.Projekcija;

public class PregledProjekcija extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao = new DAO();
 
        request.setAttribute("projekcije", dao.listaprojekcija());
        request.setAttribute("sale", dao.listaSala());
        request.setAttribute("filmovi", dao.listafilmova());
        request.setAttribute("bioskopi", dao.listabioskopa());
        request.setAttribute("gradovi", dao.listagradova());
        request.setAttribute("tehnologije", dao.listatehnologija());
        request.getRequestDispatcher("pregledprojekcija.jsp").forward(request, response);

    }

}
