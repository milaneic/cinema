/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servleti;

import DAO.DAO;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import beans.*;

public class PrikaziSedista extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("---------------------------  "+request.getParameter("projekcija"));
        int projekcija = Integer.parseInt(request.getParameter("projekcija"));
        
        String sala = request.getParameter("sala");
        ArrayList<Sediste> sedista = new ArrayList<Sediste>();
        DAO dao = new DAO();


            request.setAttribute("sedista", dao.listasedistapoSali(Integer.parseInt(sala)));

            request.setAttribute("zauzeta_sedista", dao.listazauzetihsedista(projekcija));
            
             request.setAttribute("projekcija_rezervacija", dao.getProjekcijaById(projekcija));

            request.getRequestDispatcher("rezervisi.jsp").forward(request, response);


    }

}
