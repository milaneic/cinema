package servleti;

import DAO.DAO;
import beans.Korisnik;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class KupiPosluzenje extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("idRezervacija"));
            double cena = Double.parseDouble(request.getParameter("cena"));
            
            Map<String, String[]> params = request.getParameterMap();

            Map<Integer, Integer> poruceno = new HashMap<Integer, Integer>();
            int br = 0;
            Object[] keys = params.keySet().toArray();

            for (int i = 1; i < params.keySet().size() - 1; i++) {
                System.out.println(keys[i] + " " + params.get(keys[i])[0]);
                poruceno.put(Integer.parseInt(keys[i].toString()), Integer.parseInt(params.get(keys[i])[0]));
            }

            DAO dao = new DAO();
            dao.InsertIntoPosluzenje(id, poruceno);
            dao.updateCena(cena, id);
            
            HttpSession sesija=request.getSession();
            Korisnik k=(Korisnik) sesija.getAttribute("korisnik");
            
            int poeni=k.getPoeni();
            int novi=poeni+ (int)(cena/2);
            dao.updatePoen(k.getId(), novi);
            sesija.removeAttribute("korisnik");
            k.setPoeni(novi);
            sesija.setAttribute("korisnik", k);
            response.sendRedirect("MojNalog");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("load");
        }

    }

}
