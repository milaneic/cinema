
package servleti;

import DAO.DAO;
import beans.Korisnik;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PrisustvujProjekciji extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try{
           String id=request.getParameter("projekcija");
           String sala=request.getParameter("sala");
           
           HttpSession sesija=request.getSession();
           Korisnik k=(Korisnik) sesija.getAttribute("korisnik");
           int poeni=k.getPoeni();
           sesija.removeAttribute("korisnik");
           int novi=poeni-1000;
           k.setPoeni(novi);
           sesija.setAttribute("korisnik", k);
           
           DAO dao=new DAO();
           dao.updatePoen(k.getId(),novi);
           
           response.sendRedirect("PrikaziSedista?projekcija="+id+"&sala="+sala+"");
           
           
           
       }catch(Exception e){
           e.printStackTrace();
       }
    }


}
