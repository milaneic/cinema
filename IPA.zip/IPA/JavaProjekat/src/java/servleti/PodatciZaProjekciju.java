
package servleti;

import DAO.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PodatciZaProjekciju extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao=new DAO();
        request.setAttribute("filmovi", dao.listafilmova());
        request.setAttribute("gradovi", dao.listagradova());
        request.setAttribute("tehnologije", dao.listatehnologija());
        request.setAttribute("bioskopi", dao.listabioskopa());
        request.setAttribute("sale", dao.listaSala());
        request.getRequestDispatcher("dodajprojekciju.jsp").forward(request, response);
    }


}
