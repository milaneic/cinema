package servleti;

import beans.Korisnik;
import DAO.DAO;
import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DetaljiKorisnik extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesija = request.getSession();
        Korisnik k = (Korisnik) sesija.getAttribute("korisnik");
        if (k != null && k.getNivo() == 1) {
            DAO  dao=new DAO();
            request.setAttribute("detaljiKorisnika", dao.detaljikorisnika(request.getParameter("id")));
            request.getRequestDispatcher("izmeni-korisnika.jsp").forward(request, response);

        } else {
            response.sendRedirect("load");
        }
    }

}
