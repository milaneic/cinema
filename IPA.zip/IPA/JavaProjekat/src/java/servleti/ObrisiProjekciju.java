
package servleti;

import DAO.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ObrisiProjekciju extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesija=request.getSession();
        if(sesija.getAttribute("korisnik")==null){
            response.sendRedirect("load");
        }
        try{
          int id=Integer.parseInt(request.getParameter("id"));
          DAO dao=new DAO();
          dao.brisiProjekcije(id);
          response.sendRedirect("PregledProjekcija");
        }catch(Exception e){
            request.setAttribute("error", e);
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
        
        
    }


}
