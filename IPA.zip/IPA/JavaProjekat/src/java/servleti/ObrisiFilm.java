package servleti;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import beans.Korisnik;
import DAO.DAO;

public class ObrisiFilm extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        HttpSession sesija = request.getSession();
        Korisnik k = (Korisnik) sesija.getAttribute("korisnik");
        if (k != null && k.getNivo() == 1) {
            DAO dao=new DAO();
            dao.brisifilm(id);
            response.sendRedirect("PregledFilmova");

        } else {
            response.sendRedirect("load");
        }
    }
}
