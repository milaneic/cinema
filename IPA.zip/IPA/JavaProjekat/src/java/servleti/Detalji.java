
package servleti;

import DAO.DAO;
import beans.Film;
import java.io.*;
import java.beans.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.beans.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Detalji extends HttpServlet {

  
  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao=new DAO();
        String id=request.getParameter("id");
        Film film=dao.detaljifilma(id);
        
        request.setAttribute("film", film);
        request.getRequestDispatcher("o-filmu.jsp").forward(request, response);
    }

    
}
