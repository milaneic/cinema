package servleti;

import beans.Film;
import beans.Korisnik;
import java.io.*;
import java.beans.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesija = request.getSession();
        String korisnicko = request.getParameter("korisnicko");
        String sifra = request.getParameter("sifra");
        ArrayList<Film> filmovi = new ArrayList<Film>();

        if (korisnicko != null && korisnicko.length() > 0 && sifra != null && sifra.length() > 0) {

            //Definisanje parametara za konekciju sa bazom
            String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
            String user = "root";
            String pass = "";

            try {

                Class.forName("com.mysql.jdbc.Driver");
                //Konekcija sa bazom
                Connection veza = DriverManager.getConnection(dbUrl, user, pass);

                PreparedStatement ps = veza.prepareStatement("SELECT * FROM korisnik WHERE korisnicko=? AND sifra=?");
                ps.setString(1, korisnicko);
                ps.setString(2, sifra);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    Korisnik k = new Korisnik(Integer.parseInt(rs.getString("id")), rs.getString("korisnicko"), rs.getString("sifra"), rs.getString("ime"), rs.getString("prezime"), rs.getString("telefon"),Integer.parseInt(rs.getString("poeni")),Integer.parseInt(rs.getString("klub")), Integer.parseInt(rs.getString("nivo")));

                    sesija.setAttribute("korisnik", k);
                    sesija.setMaxInactiveInterval(600);
                    sesija.setAttribute("nivo", k.getNivo());
                    response.sendRedirect("load");
                    
                    ps.close();
                    veza.close();

                } else {
                    request.setAttribute("msg", "Korisnik sa datim parametrima ne postoji ili podatci nisu tacni.");
                    request.getRequestDispatcher("login.jsp").forward(request, response);
                }

            } catch (Exception e) {
                request.setAttribute("error", e);
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("msg", "Molim vas da popunite sva polja pre logovanja.");
            request.getRequestDispatcher("Login.jsp").forward(request, response);
        }

    }

}
