package servleti;

import java.io.*;
import java.sql.*;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.http.*;
import beans.*;

public class DodajFilm extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String naziv = request.getParameter("naziv");
        String slika = request.getParameter("slika");
        String opis = request.getParameter("opis");
        String godina = request.getParameter("godina");
        String direktor = request.getParameter("direktor");
        String pisci = request.getParameter("producent");
        String glumci = request.getParameter("glumci");
        String trailer = request.getParameter("trailer");
        String trajanje = request.getParameter("trajanje");
        String ocena = request.getParameter("ocena");
        String zanr = request.getParameter("zanr");

        if (naziv != null && naziv.length() > 0 && slika != null && slika.length() > 0 && opis != null && opis.length() > 0 && godina != null && godina.length() > 0 && direktor != null && direktor.length() > 0 && glumci != null && glumci.length() > 0 && trailer != null && trailer.length() > 0 && trajanje != null && trajanje.length() > 0 && ocena != null && ocena.length() > 0 && zanr != null && zanr != "") {
            String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
            String user = "root";
            String pass = "";

            try {
                Class.forName("com.mysql.jdbc.Driver");
                //Konekcija sa bazom
                Connection veza = DriverManager.getConnection(dbUrl, user, pass);

                PreparedStatement ps = veza.prepareStatement("INSERT INTO film(naziv,slika,opis,producent,pisci,glumci,trailer,trajanje,godina,ocena,zanr) VALUES("
                        + "'" + naziv + "','" + slika + "','" + opis + "','" + direktor + "','" + pisci + "','" + glumci + "','" + trailer + "','" + trajanje + "','" + godina + "', '" + ocena + "','" + zanr + "')");
                ps.executeUpdate();
                response.sendRedirect("load");
            } catch (Exception e) {
                request.setAttribute("error", e);
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("msg", "Molim vas da popunite sva polja pre dodavanja filma");
            request.getRequestDispatcher("dodajfilm.jsp").forward(request, response);
        }

    }
}
