
package servleti;

import DAO.DAO;
import beans.Korisnik;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UclaniUKlub extends HttpServlet {

   
   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
            HttpSession sesija=request.getSession();
            Korisnik k=(Korisnik) sesija.getAttribute("korisnik");
            
            int idKorisnika=Integer.parseInt(request.getParameter("idk"));
            int klub=Integer.parseInt(request.getParameter("klub"));
            
            k.setKlub(klub);
            sesija.removeAttribute("korisnik");
            sesija.setAttribute("korisnik", k);
            
            DAO dao=new DAO();
            dao.updateKlub(idKorisnika, klub);
            
            response.sendRedirect("MojNalog");
          
            
            

            
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    
}
