
package servleti;

import DAO.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PregledRezervacija extends HttpServlet {


    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
           int id=Integer.parseInt(request.getParameter("id")); 
           DAO dao=new DAO();
           request.setAttribute("rezervisana_sedista", dao.listaSedistaByIdRezervacija(id));
           request.setAttribute("posluzenje_naruceno", dao.listaposluzenjaByIdRezervacija(id));
           request.setAttribute("sale", dao.listaSala());
           request.setAttribute("sedista", dao.listaSedista());
           request.setAttribute("rezervacija", dao.getRezervacijaRenderById(id));
           request.getRequestDispatcher("rezervacija.jsp").forward(request, response);
        }catch(Exception e){
            e.printStackTrace();
        }
       
       
     
    }



}
