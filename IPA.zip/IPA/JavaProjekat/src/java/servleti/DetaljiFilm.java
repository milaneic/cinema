
package servleti;

import beans.Film;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DetaljiFilm extends HttpServlet {


   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id=request.getParameter("id");
        //Definisanje parametara za konekciju sa bazom
            String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
            String user = "root";
            String pass = "";

            try {
                
                Class.forName("com.mysql.jdbc.Driver");
                //Konekcija sa bazom
                Connection veza = DriverManager.getConnection(dbUrl, user, pass);
                
                PreparedStatement ps=veza.prepareStatement("SELECT * FROM film WHERE id='"+id+"'");
                ResultSet rs=ps.executeQuery();
                
                if(rs.next()){
                   Film detalji=new Film(Integer.parseInt(rs.getString("id")),rs.getString("naziv"),
                                rs.getString("slika"),rs.getString("opis"),rs.getString("producent"),rs.getString("pisci"),
                        rs.getString("glumci"),rs.getString("trailer"),Integer.parseInt(rs.getString("trajanje")),
                                Integer.parseInt(rs.getString("godina")),Double.parseDouble(rs.getString("ocena")),Integer.parseInt(rs.getString("zanr")));
                   ps.close();
                   veza.close();
                   request.setAttribute("detaljiFilma", detalji);
                   request.getRequestDispatcher("izmeni-film.jsp").forward(request, response);
                }
            }catch(Exception e){
                request.setAttribute("error", e);
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
    }

    
}
