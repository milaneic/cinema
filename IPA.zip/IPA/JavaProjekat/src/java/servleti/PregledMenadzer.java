
package servleti;

import DAO.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PregledMenadzer extends HttpServlet {


   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
            DAO dao=new DAO();
            request.setAttribute("tabela", dao.getMenadzerRender());
            request.setAttribute("najprodavaniji", dao.getMostSelledMovie());
            request.setAttribute("posluzenje", dao.MostSelledFoodAndDring());
            
            request.getRequestDispatcher("pregled-menadzer.jsp").forward(request, response);
        }catch(Exception e){
            e.printStackTrace();
        }
    }


}
