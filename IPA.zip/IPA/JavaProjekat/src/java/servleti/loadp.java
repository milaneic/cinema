package servleti;

import DAO.DAO;
import java.io.*;
import java.sql.*;
import beans.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class loadp extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        DAO dao = new DAO();
        
        request.setAttribute("projekcije", dao.listaprojekcija());
        request.setAttribute("sale", dao.listaSala());
        request.setAttribute("filmovi", dao.listafilmova());
        request.setAttribute("bioskopi", dao.listabioskopa());
        request.setAttribute("gradovi", dao.listagradova());
        request.setAttribute("tehnologije", dao.listatehnologija());

        request.getRequestDispatcher("projekcije.jsp").forward(request, response);
    }

}
