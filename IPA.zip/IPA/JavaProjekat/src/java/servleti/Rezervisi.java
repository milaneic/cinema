package servleti;

import DAO.DAO;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import beans.Korisnik;
import beans.Rezervacija;

/**
 *
 * @author milaa
 */
public class Rezervisi extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            DAO dao = new DAO();
            HttpSession sesija = request.getSession();
            Korisnik k = (Korisnik) sesija.getAttribute("korisnik");

            String odabrana = (String) request.getParameter("odabrana");
            String[] array = odabrana.split(",");
            String cena = request.getParameter("cena_ukupno");
            String projekcija = request.getParameter("projekcija");
            String poeni = request.getParameter("poeni");

            if (poeni != null && poeni.length() > 0) {

                int p = Integer.parseInt(poeni);
                System.out.println(p);
                System.out.println(k);
                k.setPoeni(p);
                System.out.println(k);
                sesija.removeAttribute("korisnik");
                sesija.setAttribute("korisnik", k);
                dao.updatePoen(k.getId(), p);
            }

            if (odabrana == "") {
                response.sendRedirect("loadp");
            } else {
                Timestamp ts = new Timestamp(System.currentTimeMillis());
                Rezervacija r = new Rezervacija(-1, Integer.parseInt(projekcija), k.getId(), Double.parseDouble(cena), ts, 0);

                int id = dao.kreirajrezervaciju(r);
                System.out.println("******" + id);
                dao.InsertIntoRezervisanaSedista(id, array);
                response.sendRedirect("load");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
