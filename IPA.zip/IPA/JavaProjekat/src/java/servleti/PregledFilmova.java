
package servleti;

import DAO.DAO;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import beans.*;
import java.util.*;
public class PregledFilmova extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao=new DAO();
        HttpSession sesija=request.getSession();
        Korisnik k=(Korisnik) sesija.getAttribute("korisnik");
        if(k!=null && k.getNivo()==1){
//        ArrayList<Film> filmovi=new ArrayList<Film>();
//        //Definisanje parametara za konekciju sa bazom
//        String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
//        String user = "root";
//        String pass = "";
//        
        try {
//
//            Class.forName("com.mysql.jdbc.Driver");
//            //Konekcija sa bazom
//            Connection veza = DriverManager.getConnection(dbUrl, user, pass);
//
//            PreparedStatement ps = veza.prepareStatement("SELECT * FROM film");
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                filmovi.add(new Film(Integer.parseInt(rs.getString("id")),rs.getString("naziv"),
//                                rs.getString("slika"),rs.getString("opis"),rs.getString("producent"),rs.getString("pisci"),
//                        rs.getString("glumci"),rs.getString("trailer"),Integer.parseInt(rs.getString("trajanje")),
//                                Integer.parseInt(rs.getString("godina")),Double.parseDouble(rs.getString("ocena")),Integer.parseInt(rs.getString("zanr"))));
//            }
//            ps.close();
//            veza.close();
            request.setAttribute("filmovi", dao.listafilmova());
            request.getRequestDispatcher("pregledfilmova.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", e);
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
        }else{
            response.sendRedirect("load");
        }
    }


}
