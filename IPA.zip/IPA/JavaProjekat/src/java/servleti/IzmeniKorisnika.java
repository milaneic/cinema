package servleti;

import DAO.DAO;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class IzmeniKorisnika extends HttpServlet {

 @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id=request.getParameter("id");
        String korisnicko = request.getParameter("korisnicko");
        String sifra = request.getParameter("sifra");
        String ime = request.getParameter("ime");
        String prezime = request.getParameter("prezime");
        String telefon = request.getParameter("telefon");
        System.out.println("Telefon jednako"+telefon);
        String poeni = request.getParameter("poeni");
        String nivo = request.getParameter("nivo");
        if (korisnicko != null && korisnicko.length() > 0 && sifra != null && sifra.length() > 0 && ime != null && ime.length() > 0 && prezime != null && prezime.length() > 0 && telefon != null && telefon.length() > 0 && poeni != null && poeni.length() > 0 && nivo != null && nivo != "") {
         DAO dao=new DAO();
        dao.izmenikorisnika(id, korisnicko, sifra, ime, prezime, telefon, poeni, nivo);
        response.sendRedirect("PregledKorisnika");
        } else {
            System.out.println("");
            request.setAttribute("msg", "Molim vas da popunite sva polja i izaberete ulogu korisnika");
            request.getRequestDispatcher("izmeni-korisnika.jsp").forward(request, response);
        }
    }
}
