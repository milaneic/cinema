package servleti;

import DAO.DAO;
import java.io.*;
import beans.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.sql.*;

public class PregledKorisnika extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesija=request.getSession();
        Korisnik k=(Korisnik) sesija.getAttribute("korisnik");
        if(k!=null && k.getNivo()==1){
            DAO dao=new DAO();
        request.setAttribute("korisnici", dao.listakorisnika());
        request.getRequestDispatcher("pregledkorisnika.jsp").forward(request, response);
        }else{
            response.sendRedirect("load");
        }
    }

}
