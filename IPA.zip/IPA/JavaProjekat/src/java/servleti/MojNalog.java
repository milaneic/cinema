package servleti;

import DAO.DAO;
import beans.Korisnik;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MojNalog extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sesija = request.getSession();
        Korisnik k = (Korisnik) sesija.getAttribute("korisnik");
        if (k != null) {
            System.out.println(k);
            DAO dao = new DAO();
            request.setAttribute("filmovi", dao.listafilmova());
            request.setAttribute("projekcija", dao.listaprojekcija());
            request.setAttribute("rezervacije", dao.listarezervacijaByKorisnik(k.getId()));
            request.setAttribute("klub", dao.listaKlubova());
            request.getRequestDispatcher("moj-nalog.jsp").forward(request, response);
        }else{
            response.sendRedirect("load");
        }

    }

}
