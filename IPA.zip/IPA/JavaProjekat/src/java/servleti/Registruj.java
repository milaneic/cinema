package servleti;

import beans.Korisnik;
import java.io.*;
import java.sql.*;
import java.beans.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Registruj extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Deklarisanje promenljivih
        String korisnicko = request.getParameter("korisnicko");
        String sifra = request.getParameter("sifra");
        String sifra2 = request.getParameter("sifra2");
        String ime = request.getParameter("ime");
        String prezime = request.getParameter("prezime");
        String telefon = request.getParameter("telefon");
        //Definisanje parametara za konekciju sa bazom
        String dbUrl = "jdbc:mysql://localhost:3306/javaprojekat";
        String user = "root";
        String pass = "";
        //provera da li je sve popunjeno
        if (korisnicko != null && korisnicko.length() > 0 && sifra != null && sifra.length() > 0 && ime != null && ime.length() > 0 && prezime != null && prezime.length() > 0 && telefon != null && telefon.length() > 0) {
            if (sifra.equals(sifra2)) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    //Konekcija sa bazom
                    Connection veza = DriverManager.getConnection(dbUrl, user, pass);

                    PreparedStatement p = veza.prepareStatement("SELECT korisnicko FROM korisnik");
                    ResultSet r = p.executeQuery();
                    while (r.next()) {
                        if (korisnicko.equals(r.getString("korisnicko"))) { // da li postoji vec korisnik sa datim korisnickim imenom
                            request.setAttribute("msg", "Korisnik sa datim korisnickim imenom vec postoji molim vas izaberite drugo.");
                            request.getRequestDispatcher("Registruj.jsp").forward(request, response);
                        }
                    }
                    // ubacivanje korisnika u bazu
                    PreparedStatement ps = veza.prepareStatement("INSERT INTO korisnik(korisnicko,sifra,ime,prezime,telefon,poeni,klub,nivo) VALUES('" + korisnicko + "','" + sifra + "','" + ime + "','" + prezime + "','" + telefon + "','0','0','3')");
                    ps.executeUpdate();
                    p.close();
                    ps.close();
                    veza.close();
                    request.setAttribute("msg", "Korisnik uspesno registrovan.");
                    request.getRequestDispatcher("registruj.jsp").forward(request, response);
                } catch (Exception e) {
                    request.setAttribute("error", e);
                    request.getRequestDispatcher("error.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("msg", "Sifre se ne poklapaju.");
                request.getRequestDispatcher("registruj.jsp").forward(request, response);
            }
        } else {
            request.setAttribute("msg", "Molim vas da popunite sva polja pre registracije.");
            request.getRequestDispatcher("registruj.jsp").forward(request, response);
        }

    }

}
