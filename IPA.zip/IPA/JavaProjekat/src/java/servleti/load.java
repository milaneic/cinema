package servleti;

import DAO.DAO;
import java.io.*;
import java.sql.*;
import beans.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class load extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao = new DAO();

        request.setAttribute("filmovi", dao.listafilmova());
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

}
