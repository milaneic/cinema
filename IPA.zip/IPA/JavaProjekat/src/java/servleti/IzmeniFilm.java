package servleti;

import DAO.DAO;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import beans.Korisnik;
import beans.Film;
import java.sql.*;
import java.util.*;

public class IzmeniFilm extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao = new DAO();
        HttpSession sesija = request.getSession();
        Korisnik k = (Korisnik) request.getAttribute("korisnik");
        String id = request.getParameter("id");
        String naziv = request.getParameter("naziv");
        String slika = request.getParameter("slika");
        String opis = request.getParameter("opis");
        String godina = request.getParameter("godina");
        String producent = request.getParameter("producent");
        String pisci = request.getParameter("pisci");
        String glumci = request.getParameter("glumci");
        String trailer = request.getParameter("trailer");
        String trajanje = request.getParameter("trajanje");
        String ocena = request.getParameter("ocena");
        String zanr = request.getParameter("zanr");
        System.out.println(naziv);
        System.out.println(slika);
        System.out.println(opis);
        System.out.println("ti si " + producent);
        if (naziv != null && naziv.length() > 0 && slika != null && slika.length() > 0 && opis != null && opis.length() > 0 && godina != null && godina.length() > 0 && producent != null && producent.length() > 0 && glumci != null && glumci.length() > 0 && trailer != null && trailer.length() > 0 && trajanje != null && trajanje.length() > 0 && ocena != null && ocena.length() > 0 && zanr != null && zanr != "") {
            try {
                Film f = new Film(Integer.parseInt(id), naziv, slika, opis, producent, pisci, glumci, trailer, Integer.parseInt(trajanje), Integer.parseInt(godina), Double.parseDouble(ocena), Integer.parseInt(zanr));
                dao.updateFIlm(f);
                response.sendRedirect("PregledFilmova");
            } catch (Exception e) {
                request.setAttribute("error", e);
                request.getRequestDispatcher("error.jsp").forward(request, response);
            }
        } else {
            System.out.println("nesto je null");
            response.sendRedirect("DetaljiFilm?id=" + id);
        }

    }
}
