/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servleti;

import DAO.DAO;
import beans.Projekcija;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.Time;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author milaa
 */
public class DodajProjekciju extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        DAO dao = new DAO();
        
        try {
            String v=request.getParameter("vreme");
            int film =Integer.parseInt(request.getParameter("film"));
            int sala =Integer.parseInt(request.getParameter("sala"));
            int tehnologija =Integer.parseInt(request.getParameter("tehnologija"));
            int premijera=Integer.parseInt(request.getParameter("premijera"));
            double cena = Double.parseDouble(request.getParameter("cena"));
            Date datum = Date.valueOf(request.getParameter("datum"));
//            System.out.println(v);
            Time vreme = Time.valueOf(v+":00");
//            System.out.println(vreme);
//           System.out.println(film + " " + sala + " " + tehnologija + " " + premijera + " " + cena + " " + datum + " " + vreme);
            
//            Projekcija p=new Projekcija(-1, film, sala, tehnologija, premijera, cena, datum, vreme);
//            dao.kreirajProjekciju(p);
//            
//            response.sendRedirect("PregledProjekcija");
            
        } catch (NumberFormatException ne) {
            request.setAttribute("poruka", "Molim vas unesti ispravne podatke!");
//            request.getRequestDispatcher("DodajProjekciju").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

}
