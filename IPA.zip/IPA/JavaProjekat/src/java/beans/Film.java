
package beans;

public class Film {
 private int id;
 private String naziv;
 private String slika;
 private String opis;
 private String producent;
 private String pisci;
 private String glumci;
 private String trailer;
 private int trajanje;
 private int godina;
 private double ocena;
 private int zanr;

    public Film() {
    }

    public Film(int id, String naziv, String slika, String opis, String producent, String pisci, String glumci, String trailer, int trajanje, int godina, double ocena, int zanr) {
        this.id = id;
        this.naziv = naziv;
        this.slika = slika;
        this.opis = opis;
        this.producent = producent;
        this.pisci = pisci;
        this.glumci = glumci;
        this.trailer = trailer;
        this.trajanje = trajanje;
        this.godina = godina;
        this.ocena = ocena;
        this.zanr = zanr;
    }

   

    

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getNaziv() {
        return naziv;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public String getPisci() {
        return pisci;
    }

    public void setPisci(String pisci) {
        this.pisci = pisci;
    }
    

    

    public String getProducent() {
        return producent;
    }

    public void setProducent(String producent) {
        this.producent = producent;
    }

    public String getGlumci() {
        return glumci;
    }

    public void setGlumci(String glumci) {
        this.glumci = glumci;
    }

    public String getTrailer() {
        return trailer;
    }

    public void setTrailer(String trailer) {
        this.trailer = trailer;
    }

    public int getTrajanje() {
        return trajanje;
    }

    public void setTrajanje(int trajanje) {
        this.trajanje = trajanje;
    }

    public int getGodina() {
        return godina;
    }

    public void setGodina(int godina) {
        this.godina = godina;
    }

  

    public void setOcena(double ocena) {
        this.ocena = ocena;
    }

    public double getOcena() {
        return ocena;
    }

   

    public int getZanr() {
        return zanr;
    }

    public void setZanr(int zanr) {
        this.zanr = zanr;
    }

    @Override
    public String toString() {
        return "Film{" + "id=" + id + ", naziv=" + naziv + ", slika=" + slika + ", opis=" + opis + ", producent=" + producent + ", pisci=" + pisci + ", glumci=" + glumci + ", trailer=" + trailer + ", trajanje=" + trajanje + ", godina=" + godina + ", ocena=" + ocena + ", zanr=" + zanr + '}';
    }
 
 
    
    
}
