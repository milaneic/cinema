
package beans;

public class Klub {
    private int id;
    private String naziv;

    public Klub() {
    }

    public Klub(int id, String naziv) {
        this.id = id;
        this.naziv = naziv;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Klub{" + "id=" + id + ", naziv=" + naziv + '}';
    }
    
    
}
