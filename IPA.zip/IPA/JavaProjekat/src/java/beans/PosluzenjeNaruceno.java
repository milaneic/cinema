    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author milaa
 */
public class PosluzenjeNaruceno {
    
    private int idRezervacije;
    private Posluzenje posluzenje;
    private int kolicina;

    public PosluzenjeNaruceno() {
    }

    public PosluzenjeNaruceno(int idRezervacije, Posluzenje posluzenje, int kolicina) {
        this.idRezervacije = idRezervacije;
        this.posluzenje = posluzenje;
        this.kolicina = kolicina;
    }

    public int getIdRezervacije() {
        return idRezervacije;
    }

    public void setIdRezervacije(int idRezervacije) {
        this.idRezervacije = idRezervacije;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public Posluzenje getPosluzenje() {
        return posluzenje;
    }

    public void setPosluzenje(Posluzenje posluzenje) {
        this.posluzenje = posluzenje;
    }

    @Override
    public String toString() {
        return "PosluzenjeNaruceno{" + "idRezervacije=" + idRezervacije + ", posluzenje=" + posluzenje + ", kolicina=" + kolicina + '}';
    }
    
    
}
