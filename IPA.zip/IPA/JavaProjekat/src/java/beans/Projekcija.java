package beans;

import java.sql.Date;
import java.sql.Time;

public class Projekcija {

    private int id;
    private int film;
    private int sala;
    private int tehnologija;
    private int premijera;
    private double cena;
    private Date datum;
    private Time vreme;

    public Projekcija() {
    }

    public Projekcija(int id, int film, int sala, int tehnologija, int premijera, double cena, Date datum, Time vreme) {
        this.id = id;
        this.film = film;
        this.sala = sala;
        this.tehnologija = tehnologija;
        this.premijera = premijera;
        this.cena = cena;
        this.datum = datum;
        this.vreme = vreme;
    }

  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public int getPremijera() {
        return premijera;
    }

    public void setPremijera(int premijera) {
        this.premijera = premijera;
    }

   

    public int getFilm() {
        return film;
    }

    public void setFilm(int film) {
        this.film = film;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getTehnologija() {
        return tehnologija;
    }

    public void setTehnologija(int tehnologija) {
        this.tehnologija = tehnologija;
    }

    public Time getVreme() {
        return vreme;
    }

    public void setVreme(Time vreme) {
        this.vreme = vreme;
    }

    @Override
    public String toString() {
        return "Projekcija{" + "id=" + id + ", film=" + film + ", sala=" + sala + ", tehnologija=" + tehnologija + ", premijera=" + premijera + ", cena=" + cena + ", datum=" + datum + ", vreme=" + vreme + '}';
    }

   
    
   
}
