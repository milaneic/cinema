/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author milaa
 */
public class Posluzenje {
    private int id;
    private String slika;
    private String naziv;
    private double cena;

    public Posluzenje() {
    }

    public Posluzenje(int id, String slika, String naziv, double cena) {
        this.id = id;
        this.slika = slika;
        this.naziv = naziv;
        this.cena = cena;
    }

  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Posluzenje{" + "id=" + id + ", slika=" + slika + ", naziv=" + naziv + ", cena=" + cena + '}';
    }


  
    
    
}
