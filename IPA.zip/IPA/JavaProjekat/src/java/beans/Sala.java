
package beans;

public class Sala {
   private int id;
   private int bioskop;
   private String naziv;
   private int kapacitet;

    public Sala() {
    }

    public Sala(int id, int bioskop, String naziv, int kapacitet) {
        this.id = id;
        this.bioskop = bioskop;
        this.naziv = naziv;
        this.kapacitet = kapacitet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBioskop() {
        return bioskop;
    }

    public void setBioskop(int bioskop) {
        this.bioskop = bioskop;
    }

    public int getKapacitet() {
        return kapacitet;
    }

    public void setKapacitet(int kapacitet) {
        this.kapacitet = kapacitet;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Sala{" + "id=" + id + ", bioskop=" + bioskop + ", naziv=" + naziv + ", kapacitet=" + kapacitet + '}';
    }
   
   
}
