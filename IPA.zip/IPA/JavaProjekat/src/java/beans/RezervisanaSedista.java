
package beans;

public class RezervisanaSedista {
    private int idRezervacija;
    private int idSediste;
    private int potvrdjeno;

    public RezervisanaSedista() {
    }

    public RezervisanaSedista(int idRezervacija, int idSediste, int potvrdjeno) {
        this.idRezervacija = idRezervacija;
        this.idSediste = idSediste;
        this.potvrdjeno = potvrdjeno;
    }




    public int getIdRezervacija() {
        return idRezervacija;
    }

    public void setIdRezervacija(int idRezervacija) {
        this.idRezervacija = idRezervacija;
    }

    public int getIdSediste() {
        return idSediste;
    }

    public void setIdSediste(int idSediste) {
        this.idSediste = idSediste;
    }

    public int getPotvrdjeno() {
        return potvrdjeno;
    }

    public void setPotvrdjeno(int potvrdjeno) {
        this.potvrdjeno = potvrdjeno;
    }

    @Override
    public String toString() {
        return "RezervisanaSedista{" + "idRezervacija=" + idRezervacija + ", idSediste=" + idSediste + ", potvrdjeno=" + potvrdjeno + '}';
    }

 
    
    
    
    
}
