package beans;

import java.sql.Timestamp;

public class MenadzerRender {

    private int id;
    private Projekcija projekcija;
    private double ukupno;
    private Timestamp kreiran;
    private int potvrdjeno;
    private Film film;//film bi trebao u projekciji
    private double ukupnoFilm;
    private int brojRezervacija;

    public MenadzerRender() {
    }

    public MenadzerRender(int id, Projekcija projekcija, double ukupno, Timestamp kreiran, int potvrdjeno, Film film, double ukupnoFilm, int brojRezervacija) {
        this.id = id;
        this.projekcija = projekcija;
        this.ukupno = ukupno;
        this.kreiran = kreiran;
        this.potvrdjeno = potvrdjeno;
        this.film = film;
        this.ukupnoFilm = ukupnoFilm;
        this.brojRezervacija = brojRezervacija;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Projekcija getProjekcija() {
        return projekcija;
    }

    public void setProjekcija(Projekcija projekcija) {
        this.projekcija = projekcija;
    }

    public double getUkupno() {
        return ukupno;
    }

    public void setUkupno(double ukupno) {
        this.ukupno = ukupno;
    }

    public Timestamp getKreiran() {
        return kreiran;
    }

    public void setKreiran(Timestamp kreiran) {
        this.kreiran = kreiran;
    }

    public int getPotvrdjeno() {
        return potvrdjeno;
    }

    public void setPotvrdjeno(int potvrdjeno) {
        this.potvrdjeno = potvrdjeno;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public double getUkupnoFilm() {
        return ukupnoFilm;
    }

    public void setUkupnoFilm(double ukupnoFilm) {
        this.ukupnoFilm = ukupnoFilm;
    }

    public int getBrojRezervacija() {
        return brojRezervacija;
    }

    public void setBrojRezervacija(int brojRezervacija) {
        this.brojRezervacija = brojRezervacija;
    }

    @Override
    public String toString() {
        return "MenadzerRender{" + "id=" + id + ", projekcija=" + projekcija + ", ukupno=" + ukupno + ", kreiran=" + kreiran + ", potvrdjeno=" + potvrdjeno + ", film=" + film + ", ukupnoFilm=" + ukupnoFilm + ", brojRezervacija=" + brojRezervacija + '}';
    }


}
