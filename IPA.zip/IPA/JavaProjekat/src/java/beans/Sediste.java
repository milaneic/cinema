
package beans;

public class Sediste {
  private int id;
  private int broj_sedista;
private int sala;
private int kategorija;
private int red;

    public Sediste() {
    }

    public Sediste(int id, int broj_sedista, int sala, int kategorija, int red) {
        this.id = id;
        this.broj_sedista = broj_sedista;
        this.sala = sala;
        this.kategorija = kategorija;
        this.red = red;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBroj_sedista() {
        return broj_sedista;
    }

    public void setBroj_sedista(int broj_sedista) {
        this.broj_sedista = broj_sedista;
    }

    public int getKategorija() {
        return kategorija;
    }

    public void setKategorija(int kategorija) {
        this.kategorija = kategorija;
    }

    public int getSala() {
        return sala;
    }

    public void setSala(int sala) {
        this.sala = sala;
    }

    public int getRed() {
        return red;
    }

    public void setRed(int red) {
        this.red = red;
    }

    @Override
    public String toString() {
        return "Sediste{" + "id=" + id + ", broj_sedista=" + broj_sedista + ", sala=" + sala + ", kategorija=" + kategorija + ", red=" + red + '}';
    }


 
}
