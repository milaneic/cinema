
package beans;

import java.sql.Timestamp;

public class Rezervacija {
    private int id;
    private int projekcija;
    private int korisnik;
    private double ukupno;
    private Timestamp kreiran;
    private int potvrdjeno;

    public Rezervacija() {
    }

    public Rezervacija(int id, int projekcija, int korisnik, double ukupno, Timestamp kreiran, int potvrdjeno) {
        this.id = id;
        this.projekcija = projekcija;
        this.korisnik = korisnik;
        this.ukupno = ukupno;
        this.kreiran = kreiran;
        this.potvrdjeno = potvrdjeno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProjekcija() {
        return projekcija;
    }

    public void setProjekcija(int projekcija) {
        this.projekcija = projekcija;
    }

    public int getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(int korisnik) {
        this.korisnik = korisnik;
    }

    public double getUkupno() {
        return ukupno;
    }

    public void setUkupno(double ukupno) {
        this.ukupno = ukupno;
    }

    public Timestamp getKreiran() {
        return kreiran;
    }

    public void setKreiran(Timestamp kreiran) {
        this.kreiran = kreiran;
    }

    public int getPotvrdjeno() {
        return potvrdjeno;
    }

    public void setPotvrdjeno(int potvrdjeno) {
        this.potvrdjeno = potvrdjeno;
    }

    @Override
    public String toString() {
        return "Rezervacija{" + "id=" + id + ", projekcija=" + projekcija + ", korisnik=" + korisnik + ", ukupno=" + ukupno + ", kreiran=" + kreiran + ", potvrdjeno=" + potvrdjeno + '}';
    }
    
    
}
