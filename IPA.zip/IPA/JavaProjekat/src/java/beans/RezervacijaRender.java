/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import java.sql.Timestamp;

public class RezervacijaRender {
    private int id;
    private Projekcija projekcija;
    private Korisnik korisnik;
    private double ukupno;
    private Timestamp kreiran;
    private int potvrdjeno;
    private Film film;//film bi trebao u projekciji

    public RezervacijaRender() {
    }

    public RezervacijaRender(int id, Projekcija projekcija, Korisnik korisnik, double ukupno, Timestamp kreiran, int potvrdjeno, Film film) {
        this.id = id;
        this.projekcija = projekcija;
        this.korisnik = korisnik;
        this.ukupno = ukupno;
        this.kreiran = kreiran;
        this.potvrdjeno = potvrdjeno;
        this.film = film;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Projekcija getProjekcija() {
        return projekcija;
    }

    public void setProjekcija(Projekcija projekcija) {
        this.projekcija = projekcija;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public double getUkupno() {
        return ukupno;
    }

    public void setUkupno(double ukupno) {
        this.ukupno = ukupno;
    }

    public Timestamp getKreiran() {
        return kreiran;
    }

    public void setKreiran(Timestamp kreiran) {
        this.kreiran = kreiran;
    }

    public int getPotvrdjeno() {
        return potvrdjeno;
    }

    public void setPotvrdjeno(int potvrdjeno) {
        this.potvrdjeno = potvrdjeno;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    @Override
    public String toString() {
        return "RezervacijaRender{" + "id=" + id + ", projekcija=" + projekcija + ", korisnik=" + korisnik + ", ukupno=" + ukupno + ", kreiran=" + kreiran + ", potvrdjeno=" + potvrdjeno + ", film=" + film + '}';
    }

    

   
   
    

   
    
    
 
}
