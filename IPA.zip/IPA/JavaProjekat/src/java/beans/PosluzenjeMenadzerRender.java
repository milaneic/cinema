
package beans;


public class PosluzenjeMenadzerRender {
    private int idRezervacije;
    private Posluzenje posluzenje;
    private int kolicina;
}
