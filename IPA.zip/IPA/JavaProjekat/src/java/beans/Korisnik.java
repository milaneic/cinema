package beans;

public class Korisnik {

    private int id;
    private String korisnicko;
    private String sifra;
    private String ime;
    private String prezime;
    private String telefon;
    private int poeni;
    private int klub;
    private int nivo;

    public Korisnik() {
    }

    public Korisnik(int id, String korisnicko, String sifra, String ime, String prezime, String telefon, int poeni, int klub, int nivo) {
        this.id = id;
        this.korisnicko = korisnicko;
        this.sifra = sifra;
        this.ime = ime;
        this.prezime = prezime;
        this.telefon = telefon;
        this.poeni = poeni;
        this.klub = klub;
        this.nivo = nivo;
    }

  

    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKorisnicko() {
        return korisnicko;
    }

    public void setKorisnicko(String korisnicko) {
        this.korisnicko = korisnicko;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public int getNivo() {
        return nivo;
    }

    public void setNivo(int nivo) {
        this.nivo = nivo;
    }

    public int getPoeni() {
        return poeni;
    }

    public void setPoeni(int poeni) {
        this.poeni = poeni;
    }

    public int getKlub() {
        return klub;
    }

    public void setKlub(int klub) {
        this.klub = klub;
    }

    @Override
    public String toString() {
        return "Korisnik{" + "id=" + id + ", korisnicko=" + korisnicko + ", sifra=" + sifra + ", ime=" + ime + ", prezime=" + prezime + ", telefon=" + telefon + ", poeni=" + poeni + ", klub=" + klub + ", nivo=" + nivo + '}';
    }

   
  
}
