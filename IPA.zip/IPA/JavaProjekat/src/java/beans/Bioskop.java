package beans;

public class Bioskop {

    private int id;
    private String naziv;
    private int grad;

    public Bioskop() {
    }

    public Bioskop(int id, String naziv, int grad) {
        this.id = id;
        this.naziv = naziv;
        this.grad = grad;
    }

    public int getId() {
        return id;
    }

    public void setGrad(int grad) {
        this.grad = grad;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getGrad() {
        return grad;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Bioskop{" + "id=" + id + ", naziv=" + naziv + ", grad=" + grad + '}';
    }
    
    
}
